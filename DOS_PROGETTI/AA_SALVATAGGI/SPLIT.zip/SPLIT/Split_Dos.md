Split_Dos.md

	Note
		esecuzione di una Split e riconposizione con un programma .exe in c++
		Tutto il progetto si trova nel file zippato Splits.zip, da studiare per 
		il suo funzionamento.
		