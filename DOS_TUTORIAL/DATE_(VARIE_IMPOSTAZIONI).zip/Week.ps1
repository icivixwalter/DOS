get-Date -uformat %W
